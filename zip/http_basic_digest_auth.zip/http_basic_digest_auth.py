from http.server import HTTPServer, BaseHTTPRequestHandler
from base64 import b64decode
import hashlib,os

#True表示使用HTTP摘要认证，False表示使用HTTP基本认证
use_digest = True

# 校验的用户名和密码，按需更改
USERNAME = 'a'
PASSWORD = 'b'
REALM = 'Secure Area'

#摘要认证需要生成challenge
def generate_digest_challenge():
    #需要在每次生成401响应时生成NONCE随机数
    NONCE = hashlib.md5(os.urandom(16)).hexdigest()
    OVERRIDE_QOP = 'auth'  # Quality of Protection
    challenge = f'nonce="{NONCE}", realm="{REALM}", qop="{OVERRIDE_QOP}"'
    return challenge

#摘要认证比较复杂
def validate_digest_authorization(authorization_header):
    if not authorization_header.startswith('Digest '):
        return False
    auth_values = {"method":'GET'} #只验证GET方法
    auth_header = authorization_header[7:]
    for value in auth_header.split(', '):
        k, v = value.split('=', 1)
        auth_values[k] = v.strip('"')
    
    # 重新计算响应
    ha1 = hashlib.md5(f"{USERNAME}:{REALM}:{PASSWORD}".encode('utf-8')).hexdigest()
    ha2 = hashlib.md5(f"{auth_values['method']}:{auth_values['uri']}".encode('utf-8')).hexdigest()
    s = f"{ha1}:{auth_values['nonce']}:{auth_values['nc']}:{auth_values['cnonce']}:auth:{ha2}"
    response = hashlib.md5(s.encode('utf-8')).hexdigest()
    
    return response == auth_values['response']

class AuthHandler(BaseHTTPRequestHandler):
    def ask_auth(self):
        self.send_response(401)
        #Digest或者Basic用来告诉浏览器使用摘要还是基本认证
        if use_digest:
            self.send_header('WWW-Authenticate', f'Digest {generate_digest_challenge()}')
        else:
            self.send_header('WWW-Authenticate', f'Basic realm="{REALM}"')
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(b"Forbidden")

    def validate(self):
        auth_header = self.headers.get('Authorization')
        if use_digest:
            #摘要认证失败
            if not validate_digest_authorization(auth_header):
                self.ask_auth()
                return
        else:
            #用于HTTP基本认证的凭证只做base64校验很简单
            if not auth_header.startswith('Basic '):
                return self.ask_auth()
            CREDENTIALS = f"{USERNAME}:{PASSWORD}"
            # base64编码的凭证
            auth_decoded = b64decode(auth_header[6:]).decode('utf-8')
            if auth_decoded != CREDENTIALS:
                self.ask_auth()
                return

        #认证成功，返回hello world
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(b"Hello World")

    def do_GET(self):
        # 检查是否有正确的认证头
        auth_header = self.headers.get('Authorization')
        if auth_header is None:
            self.ask_auth()
            return

        # 解码认证信息
        self.validate()

def run(server_class=HTTPServer, handler_class=AuthHandler):
    server_address = ('', 4000)
    httpd = server_class(server_address, handler_class)
    print("Starting httpd server on port 4000...")
    httpd.serve_forever()

if __name__ == '__main__':
    run()